//
// Created by zyc on 18-1-9.
//

#ifndef PERMUTATION_FUNCTION_H
#define PERMUTATION_FUNCTION_H

#include <vector>

std::vector<int> generate_vector(int argc, char *argv[]);
void recursion(std::vector<int> num, int i, int j, std::vector<std::vector<int> > &res);
std::vector<std::vector<int> > permuteUnique(std::vector<int>& num);

#endif //PERMUTATION_FUNCTION_H