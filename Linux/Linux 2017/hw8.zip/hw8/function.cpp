//
// Created by zyc on 18-1-9.
//

#include <cstdlib>
#include <vector>
#include <algorithm>

std::vector<int> generate_vector(int argc, char *argv[]) {
    std::vector<int> res;
    for (int i = 1; i < argc; ++i) {
        res.push_back(atoi(argv[i]));
    }
    return res;
}

void recursion(std::vector<int> num, int i, int j, std::vector<std::vector<int> > &res) {
    if (i == j - 1) {
        res.push_back(num);
        return;
    }
    for (int k = i; k < j; ++k) {
        if (i != k && num[i] == num[k]) continue;
        std::swap(num[i], num[k]);
        recursion(num, i + 1, j, res);
    }
}

std::vector<std::vector<int> > permuteUnique(std::vector<int>& num) {
    std::sort(num.begin(), num.end());
    std::vector<std::vector<int> >res;
    recursion(num, 0, num.size(), res);
    return res;
}
