#include <iostream>
#include "function.h"

int main(int argc, char* argv[]) {
    std::vector<int> in_vec = generate_vector(argc, argv);
    std::cout << "output:" << std::endl;
    std::vector<std::vector<int> > res = permuteUnique(in_vec);
    for (int i = 0; i < res.size(); ++ i) {
        for (int j = 0; j < res[i].size(); ++ j) {
            std::cout << res[i][j] << '\t';
        }
        std::cout << std::endl;
    }
    return 0;
}